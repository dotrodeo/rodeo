%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-18T13:35:58-04:00*%
%TF.ProjectId,rodeo-audio-3.5mm-panel,726f6465-6f2d-4617-9564-696f2d332e35,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-18 13:35:58*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H4*%
X105000000Y-105000000D03*
%TD*%
%TO.C,H2*%
X165000000Y-105000000D03*
%TD*%
%TO.C,H1*%
X165000000Y-135000000D03*
%TD*%
%TO.C,H3*%
X105000000Y-135000000D03*
%TD*%
M02*
